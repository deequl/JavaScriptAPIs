const APIURL = '/api/todos/';

export async function getTodos(){
    return fetch(APIURL)
    .then(resp => {
        //check for any errors
        if(!resp.ok) {
            if(resp.status >= 400 && resp.status < 500){
                return resp.json().then(data => {
                    let err = {errorMessage: data.message};
                    throw err;
                })
            } else {
                let err = {errorMessage: 'Please try again later, server is not responding'};
                throw err;
            }
        }
        return resp.json();
    })
}